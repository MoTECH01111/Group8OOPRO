package HealthApp;


/**
 *
 * @author Morris Ouedraogo
 */
public class MyhealthApp {

    // Main Method
    public static void main(String[] args) {
        Login myGUI = new Login(); // access to login page
        myGUI.setVisible(true);// Allows access to the Login GUI

    }
    
}
